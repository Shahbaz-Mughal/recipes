from flask import Flask

app = Flask(__name__)

app.secret_key = 'chef shabooooom 2020 quaratine baby!'